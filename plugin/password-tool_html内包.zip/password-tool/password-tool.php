<?php
/**
 * Plugin Name: Password Tool
 * Description: ショートコードでパスワード生成ツールを埋め込みます。
 * Version: 1.0
 * Author: shuno
 */

function password_tool_shortcode_handler() {
    // ツール用のCSSとJSを読み込む
    wp_enqueue_style(
        'password-tool-css',
        plugin_dir_url(__FILE__) . 'password-tool.css',
        array(),
        '1.0'
    );
    wp_enqueue_script(
        'password-tool-js',
        plugin_dir_url(__FILE__) . 'password-tool.js',
        array(),
        '1.0',
        true
    );

    ob_start();
    ?>
    <div id="password-tool-container" class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen flex flex-col">
        <div class="flex-grow flex items-center justify-center p-4">
            <div class="bg-white dark:bg-gray-800 shadow-xl rounded-2xl p-8 max-w-lg w-full transition-all duration-300">
                <h1 class="text-3xl md:text-4xl font-bold text-center mb-2">パスワード生成ツール</h1>
                <p class="text-center text-gray-600 dark:text-gray-400 mb-6">強力で安全なパスワードを簡単に作成できます。</p>
                <div class="relative flex items-center justify-between bg-gray-200 dark:bg-gray-700 rounded-xl p-4 mb-4">
                    <span id="password-display" class="text-xl md:text-2xl font-mono truncate mr-4">パスワード生成</span>
                    <button id="copy-main-btn" class="flex-shrink-0 flex items-center justify-center p-2 rounded-full bg-indigo-500 hover:bg-indigo-600 text-white transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5">
                            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                        </svg>
                    </button>
                    <div id="copy-message-main" class="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1 bg-green-500 text-white text-xs rounded-full opacity-0 transition-opacity duration-300">
                        コピーしました！
                    </div>
                </div>
                <div class="mb-6">
                    <div class="text-sm font-medium mb-1">パスワードの強度: <span id="strength-text" class="font-bold">弱</span></div>
                    <div class="w-full bg-gray-300 dark:bg-gray-600 h-2 rounded-full">
                        <div id="strength-bar" class="h-2 rounded-full w-0"></div>
                    </div>
                </div>
                <div class="space-y-4">
                    <div>
                        <label for="length-range" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            文字数 (4〜40文字) (<span id="length-value" class="font-bold text-indigo-500">12</span>文字)
                        </label>
                        <div class="flex items-center space-x-2 mb-4">
                            <input type="range" id="length-slider" min="4" max="40" value="12" class="w-full h-2 rounded-lg appearance-none cursor-pointer range-lg">
                            <input type="number" id="length-input" min="4" max="40" value="12" class="w-16 text-center py-1 px-2 bg-gray-200 dark:bg-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div class="flex space-x-2" id="preset-buttons">
                            <label class="cursor-pointer flex-1 text-center py-2 px-4 rounded-lg border border-gray-300 dark:border-gray-600 peer-checked:bg-indigo-500 peer-checked:text-white peer-checked:border-indigo-500 transition-colors duration-200 hover:bg-gray-300 dark:hover:bg-gray-600" for="preset-8">
                                <input type="radio" name="length-preset" id="preset-8" value="8" class="hidden peer">8
                            </label>
                            <label class="cursor-pointer flex-1 text-center py-2 px-4 rounded-lg border border-gray-300 dark:border-gray-600 peer-checked:bg-indigo-500 peer-checked:text-white peer-checked:border-indigo-500 transition-colors duration-200 hover:bg-gray-300 dark:hover:bg-gray-600" for="preset-12">
                                <input type="radio" name="length-preset" id="preset-12" value="12" class="hidden peer" checked>12
                            </label>
                            <label class="cursor-pointer flex-1 text-center py-2 px-4 rounded-lg border border-gray-300 dark:border-gray-600 peer-checked:bg-indigo-500 peer-checked:text-white peer-checked:border-indigo-500 transition-colors duration-200 hover:bg-gray-300 dark:hover:bg-gray-600" for="preset-16">
                                <input type="radio" name="length-preset" id="preset-16" value="16" class="hidden peer">16
                            </label>
                            <label class="cursor-pointer flex-1 text-center py-2 px-4 rounded-lg border border-gray-300 dark:border-gray-600 peer-checked:bg-indigo-500 peer-checked:text-white peer-checked:border-indigo-500 transition-colors duration-200 hover:bg-gray-300 dark:hover:bg-gray-600" for="preset-32">
                                <input type="radio" name="length-preset" id="preset-32" value="32" class="hidden peer">32
                            </label>
                        </div>
                    </div>
                    <div>
                        <div class="grid grid-cols-2 gap-4">
                            <label class="flex items-center text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" id="uppercase" checked class="form-checkbox h-5 w-5 text-indigo-600 rounded-md transition duration-150 ease-in-out"><span class="ml-2">大文字</span>
                            </label>
                            <label class="flex items-center text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" id="lowercase" checked class="form-checkbox h-5 w-5 text-indigo-600 rounded-md transition duration-150 ease-in-out"><span class="ml-2">小文字</span>
                            </label>
                            <label class="flex items-center text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" id="numbers" checked class="form-checkbox h-5 w-5 text-indigo-600 rounded-md transition duration-150 ease-in-out"><span class="ml-2">数字</span>
                            </label>
                            <label class="flex items-center text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" id="symbols" checked class="form-checkbox h-5 w-5 text-indigo-600 rounded-md transition duration-150 ease-in-out"><span class="ml-2">記号</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="mt-6 flex">
                    <button id="generate" class="flex-1 py-3 px-4 bg-indigo-600 text-white font-semibold rounded-lg shadow-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 hover:bg-indigo-700 w-full">生成</button>
                </div>
                <div class="mt-8 pt-4 border-t border-gray-300 dark:border-gray-700">
                    <div class="relative flex items-center justify-between mb-4">
                        <h2 class="text-xl font-bold text-white">他の候補</h2>
                        <button id="copy-all" class="flex items-center space-x-1 text-sm text-green-500 hover:text-green-600 transition-colors duration-200">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4">
                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                            </svg>
                            <span>すべてコピー</span>
                        </button>
                        <div id="copy-message-all" class="absolute bottom-full right-0 mb-2 px-3 py-1 bg-green-500 text-white text-xs rounded-full opacity-0 transition-opacity duration-300">
                            コピーしました！
                        </div>
                    </div>
                    <div id="result" class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3.5 border border-gray-300 dark:border-gray-700 rounded-lg p-4">
                    </div>
                </div>
                <div class="mt-8 p-4 rounded-xl bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-sm">
                    <h2 class="text-lg font-semibold mb-2 text-white">ツールの説明</h2>
                    <p class="mb-2">このツールは、以下の設定に基づいてランダムなパスワードを生成します。</p>
                    <ul class="list-disc list-inside space-y-1">
                        <li><strong class="font-bold">文字数:</strong> スライダーまたは入力欄で4文字から40文字までの長さを設定できます。</li>
                        <li><strong class="font-bold">文字種:</strong> 大文字、小文字、数字、記号を自由に組み合わせることができます。</li>
                        <li><strong class="font-bold">パスワード強度:</strong> パスワードの長さと文字種を考慮して、リアルタイムで強度を評価します。</li>
                        <li><strong class="font-bold">複数の候補:</strong> 複数のパスワード候補を生成し、お好みのものを選択できます。</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="w-full text-center py-6">
            <a href="https://chameleons.co.jp/work/category/tools/" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-full shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200 ease-in-out transform hover:scale-105">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                </svg>
                「便利ツール」一覧に戻る
            </a>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('password_tool', 'password_tool_shortcode_handler');